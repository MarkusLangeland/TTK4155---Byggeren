/*
 * timer.c
 *
 * Created: 26.10.2023 17:26:33
 *  Author: karitro
 */ 
