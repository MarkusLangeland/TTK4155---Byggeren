#pragma once 
#include "sleep.h"
#include "sam.h"

void solenoid_button();
void solenoid_init();