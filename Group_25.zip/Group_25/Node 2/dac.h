#pragma once 
#include "sam.h"
#include <stdint.h>

void dac_init(); 
void dac_write(int value); 
