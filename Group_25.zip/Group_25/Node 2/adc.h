#pragma once 
#include <stdint.h>
#include "sam.h"

void adc_init();
uint16_t adc_read();
