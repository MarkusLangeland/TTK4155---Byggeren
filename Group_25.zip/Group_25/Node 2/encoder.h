#pragma once 
#include "motor.h"
int16_t encoder_read();
