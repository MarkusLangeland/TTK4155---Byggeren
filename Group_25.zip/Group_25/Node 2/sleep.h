#pragma once 

void delay_us(int us);