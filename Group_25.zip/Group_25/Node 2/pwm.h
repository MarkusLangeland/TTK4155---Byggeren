#pragma once

void pwm_init();
void pwm_set_duty_cycle(float duty_cycle);

