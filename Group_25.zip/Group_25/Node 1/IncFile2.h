/*
 * IncFile2.h
 *
 * Created: 19.10.2023 16:26:04
 *  Author: karitro
 */ 


#ifndef INCFILE2_H_
#define INCFILE2_H_


enum {
	sync = 1,
	proqSeg = 2,
	ps1 = 2,
	ps2 = 3
	};



#endif /* INCFILE2_H_ */