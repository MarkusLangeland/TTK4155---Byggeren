#pragma once 
#include "avr/pgmspace.h"

const unsigned char PROGMEM font8[95][8];
const unsigned char PROGMEM font5[95][5];
const unsigned char PROGMEM font4[95][4];
