
#ifndef MENU_H_
#define MENU_H_

void menu_init();

#endif /* MENU_H_ */